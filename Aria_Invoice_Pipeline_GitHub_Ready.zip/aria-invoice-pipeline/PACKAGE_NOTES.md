# Package notes

## Provenance

The four `.gs` files and `appsscript.json` are copied **byte-for-byte** from the previously supplied `Aria_Invoice_Pipeline_Viewer_Kit.zip`. The five sample PDFs, CSV mapping, and sample email content are also preserved without edits.

This GitHub-ready packaging pass updates documentation and organization only. It is **not an export of the Apps Script project currently installed in the creator's Google account**. In particular, the later conversational patch that exposed sanitized provider error details has not been silently substituted into `Extract.gs`.

## Documentation corrections

- Clarifies that Default Currency is not applied by the current extraction/output code.
- Clarifies that the GL default is stored on the invoice header, not independently classified for every line.
- Distinguishes retries from revalidation and current status from a full audit log.
- Documents private credential handling, model/fee eligibility uncertainty, and a one-invoice-first setup sequence.
- Includes known prototype limitations instead of presenting the download as production-ready.

## Checks for this package

JavaScript syntax was checked locally for all four modules and the combined source; the JSON manifest was parsed; source checksums were compared; PDFs were checked as readable, one-page synthetic files; and the archive was checked for integrity. Text and document metadata were scanned for common secret patterns and the creator's operational identifiers. No live API request or Google-account execution was performed for this packaging pass. These are packaging checks, not a security certification or proof of extraction accuracy.

`SHA256SUMS.txt` contains checksums of the packaged files, excluding the checksum file itself.
